<?php

include('check_login_status.php');
$_question_id = '';
$question_details = array();
$_problem_area = array();

if(! $USER_OK){
    alert("Please login");
    header("location: index.php");
    exit();
}

if(isset($_GET["question_id"])){
    $_question_id = $_GET["question_id"];
}

if(isset($_GET['submit'])){
    echo "submit";
}

?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Byte Code - Your Problem Our Solution</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom My Own CSS -->
    <link href="css/mycss.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
  <script type="text/javascript" charset="utf-8" src="js/jquery.leanModal.min.js"></script>
  <script type="text/javascript" src="js/myjs.js" ></script>
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
        <div class="container topnav">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand topnav" href="#">ByteCode</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                     <?php 
                        if($USER_OK){ ?>
                            <li>
                                <a id="Btn" class="dropdown-toggle" id="menu1" data-toggle="dropdown"><?php echo $USER_NAME; ?> </a>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="user.php">My Dashboard</a></li>
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="logout.php">logout</a></li>
                                </ul>
                            <li>
                        <?php
                        } ?>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Header -->
    <a name="about"></a>
    <div>
        <div class="container">

            <div class="row">
            <div class="container">
                <br><br><br>
            <form  id="myForm" action="user.php" method='post' name="myForm" class="form-horizontal" role="form">
                <center><h2>Problem Statement</h2></center>
                <?php
                    $db= new db();
                    $conn=$db->db_connect();
                    $solution = '';
                    $bounty_user = NULL;
                    $res=$db->db_query($conn, $_config['get_problem_area']);
                    if($res){
                        if($res->num_rows > 0){
                            while($record = $res->fetch_assoc()){
                                $_problem_area[$record['area_id']]=$record['area'];
                            }
                        }else{
                            echo "No Problem status found";
                        }
                    }
                    $res=$db->db_query($conn, $_config['get_problems'].' where question_id = '.$_question_id);
                    if($res){
                        if($res->num_rows > 0){
                            while($record = $res->fetch_assoc()){
                                $_question_details=$record;
                            }
                        }
                    }else{
                        echo "No problems found";
                    }     
                    $res=$db->db_query($conn, $_config['get_bounty'].' where question_id = '.$_question_id);
                    if($res){
                        if($res->num_rows > 0){
                            while($record = $res->fetch_assoc()){
                                $solution = $record['solution'];
                                $bounty_user = $record['user_id'];
                            }
                        }
                    }   
                    $db->db_close($conn);    
                ?>
                
                <div class="form-group">
                    <label for="empId" class="col-sm-3 control-label">Employee ID</label>
                    <div class="col-sm-9">
                        <input type="text" name="user_id" class="form-control" value=<?php echo $_question_details["user_id"]; ?> readonly>
                    </div>
                </div>
                <div class="form-group">
                    <label for="Area" class="col-sm-3 control-label">Problem Area</label>
                    <div class="col-sm-9">
                       <input type="text" name="area_id" class="form-control" value=<?php echo $_problem_area[$_question_details["area_id"]]; ?> readonly>
                    </div>
                </div>
                <input type="hidden" name="question_id" class="form-control" value=<?php echo $_question_details["question_id"]; ?> readonly> 
                <div class="form-group">
                    <label for="problem" class="col-sm-3 control-label" >Problem Description</label>
                    <div class="col-sm-9">
                        <textarea rows=8 class="form-control" disabled><?php echo $_question_details["question"]; ?></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label for="NeededBy" class="col-sm-3 control-label">Needed By</label>
                    <div class="col-sm-9">
                        <input class="form-control" value=<?php echo $_question_details["needed_date"]; ?> disabled>
                    </div>
                </div>
 <!-- /.form-group -->
                <div class="form-group">
                    <label for="bounty" class="col-sm-3 control-label">Bounty Offer</label>
                    <div class="col-sm-9">
                        <textarea class="form-control" disabled><?php echo $_question_details["bounty"]; ?></textarea>
                    </div>
                </div>
                <?php 
                    if($_question_details['status_id'] !=1 ){
                    ?>
                        <div class="form-group">
                        <label for="problem" class="col-sm-3 control-label">Solution</label>
                        <div class="col-sm-9">
                            <textarea name="solution" id="solution" class="form-control"><?php echo $solution; ?></textarea>
                            <span class="help-block">Ex: Git Hub URL</span>
                        </div>
                    </div>
                    <?php
                    }
                ?>
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <?php
                            $submit = "Accept Bounty";
                            $disabled = "";
                            if($_question_details['status_id'] == 1){
                                $submit = "Accept Bounty";
                            }elseif($_question_details['status_id'] == 2){
                                $submit = "Submit";
                            }elseif($_question_details['status_id'] == 3){
                                $submit = "Accept";
                                echo $USER_ID;
                                echo $bounty_user;
                                $disabled = $USER_ID == $bounty_user ? "disabled='disabled'" : ""; 
                            }elseif($_question_details['status_id'] == 4){
                                $submit = "Completed";
                            }?>
                        <button type="submit" name="submit" class="btn btn-primary btn-block" <?php echo $disabled; ?> >
                        <?php echo $submit; ?>
                        
                        </button>
                    </div>
                </div>
            </form> <!-- /form -->
        </div> <!-- ./container -->
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.intro-header -->

   




    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
