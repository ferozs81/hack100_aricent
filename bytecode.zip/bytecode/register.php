<?php

/*include('server/db.php');
$_config = include('server/utils.php');
*/
require ("hash.php");
include('check_login_status.php');
    $error = "";
if(isset($_POST['empID']) && isset($_POST['email']) && isset($_POST['password']) ){
    
    $db= new db();
    $error_status = FALSE;

    if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false) {
        $error = $_POST['email']." is not a valid email address";
        $error_status = TRUE;
    }
    $user = explode("@", $_POST['email']);
    $user_name = $user[0];
    $user_lname = " ";
    $pass_hash = PassHash::hash($_POST['password']);
    echo $pass_hash;
    $conn=$db->db_connect();
    $res=$db->db_query($conn, "INSERT into users (user_id,user_name,user_lname,user_pass,user_mail) values (".$_POST['empID'].",'".$user_name."','".$user_lname."','".$pass_hash."','".$_POST['email']."')");
    var_dump($res);
    if($res){
        var_dump($res);
        $error = "User Inserted";
        header("location: index.php");
        exit();
    }else{
        $error = "Failed to inser user";
        echo $error;
    }
    $db->db_close($conn);

}


?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Byte Code - Your Problem Our Solution</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom My Own CSS -->
    <link href="css/mycss.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
  <script type="text/javascript" charset="utf-8" src="js/jquery.leanModal.min.js"></script>
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
        <div class="container topnav">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand topnav" href="#">Register</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    
                     <?php 
                        if($USER_OK){ ?>
                            <li>
                                <a id="Btn" class="dropdown-toggle" id="menu1" data-toggle="dropdown"><?php echo $USER_NAME; ?> </a>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="user.php">My Dashboard</a></li>
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="logout.php">logout</a></li>
                                </ul>
                            <li>
                        <?php
                        } ?>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Header -->
    <a name="about"></a>
    <div>
        <div class="container">

            <div class="row">
            <div class="container">
                <br><br><br>
            <form class="form-horizontal" role="form" method="post" data-toggle="validator">
                <center><h2>Registration Form</h2></center>
                <div class="form-group">
                    <label for="empId" class="col-sm-3 control-label">Employee ID</label>
                    <div class="col-sm-9">
                        <input type="number" id="empID" name="empID" placeholder="Employee ID" class="form-control" required>
                        <span class="help-block">EmpID:HYD42333</span>
                    </div>
                </div>
                 <div class="form-group">
                    <label for="bounty" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input maxlength="100" type="text" id="email" name="email" placeholder="example@aricent.com" class="form-control" required>
                    </div>
                </div>
                 <div class="form-group">
                    <label for="bounty" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input maxlength="100" type="password" id="password" name="password" class="form-control" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" class="btn btn-primary btn-block" >Register</button>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <?php 
                            $disabled = $error == "" ? "disabled='disabled'" : "";  ?>
                        <label for="bounty" class="col-sm-3 control-label" <?php echo $disabled; ?>><?php echo $error; ?></label>
                    </div>
                </div> <!-- /.form-group -->
            </form> <!-- /form -->
        </div> <!-- ./container -->
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.intro-header -->

   




    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
<?php

if (isset($_POST['empID']) && isset($_POST['area']) && isset($_POST['problem'])
    && isset($_POST['needby']) && isset($_POST['bounty'])){
    $error_state = FALSE;
    $error="";

    if(empty($_POST['bounty'])){
        $error = $error . "  bounty is required;";
        $error_state = TRUE;
    }
    if(empty($_POST['needby'])){
        $error = $error . " Needed by date is required;"; 
        $error_state = TRUE;
    }
    if(empty($_POST['area'])){
        $error = $error . " Problem area is required;"; 
        $error_state = TRUE;
    }
    if(empty($_POST['empID'])){
        $error = $error . " Problem area is required;"; 
        $error_state = TRUE;
    }
    
    if(! $error_state){
        $conn = $db->db_connect();
        $create_date = date('Y-m-d H:i:s');
        $update_date = date('Y-m-d H:i:s');
        $needed_date = date('Y-m-d H:i:s');
        $area_id =$_problem_area[$_POST['area']];
        $question_state = $_config['question_state'];
        $user_query = $_config['select_user']. $_POST['empID'];
        $bounty = $conn->real_escape_string($_POST['bounty']);
        $problem = $conn->real_escape_string($_POST['problem']);
        $sql_query = $_config['create_ques_prifix'].
                    "VALUES('".$problem."','".$bounty."','".$create_date."','".
                    $update_date."','".$_POST['needby']."',".$area_id.",".$question_state.",".$_POST['empID'].")";

        $res=$db->db_query($conn,$user_query);
        if($res){
            if($res->num_rows > 0){
                $result=$db->db_insertRecord($conn,$sql_query);
                if($result){
                    echo "Record inserted";
                }else{
                    echo "Failed to insert record";
                }
            }else{
                echo "No user Found";
            }
        }else{
            echo "No set";
        }
        $db->db_close($conn);
    }
    else{
        echo $error;
    }
    
}


?>