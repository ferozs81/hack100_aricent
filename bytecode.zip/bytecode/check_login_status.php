<?php

session_start();
include('server/db.php');
$_config = include('server/utils.php');

$USER_OK=FALSE;
$USER_ID="";
$USER_NAME="";
$USER_MAIL="";

function evaluate_user($mail,$pass,$id){
    global $_config;
    $db = new db();
    $conn = $db->db_connect();
    $sql_query = "SELECT * from users where user_id = ".$id." and user_mail = '".
                    $mail."' and user_pass = '".$pass."'";
    $res=$db->db_query($conn,$sql_query);
    if($res->num_rows > 0 ){
        $db->db_close($conn);
        return TRUE;
    }
    $db->db_close($conn);
    return FALSE;
}

if(isset($_SESSION['userid']) && isset($_SESSION['username'])
  && isset($_SESSION['usermail']) && isset($_SESSION['userpass'])){
    $USER_ID=$_SESSION['userid'];
    $USER_NAME=$_SESSION['username'];
    $USER_MAIL=$_SESSION['usermail'];
    $USER_OK = evaluate_user($_SESSION['usermail'],$_SESSION['userpass'],$_SESSION['userid']);  
}else{
    //echo "Session not set";
}

?>