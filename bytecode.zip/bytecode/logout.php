<?php
session_start();

$_SESSION = array();

session_destroy();


if(isset($_SESSION['userid']) && isset($_SESSION['username'])
  && isset($_SESSION['usermail']) && isset($_SESSION['userpass'])){
    header("location: index.php");
}else{
    header("location: index.php");
    exit();
}


?>