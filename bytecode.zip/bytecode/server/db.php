<?php

$_config = include('utils.php');

class db{
    var $db_status=FALSE;
    var $conn = NULL;
    
    function db_connect(){
        global $_config;
        $conn = new mysqli($_config['host'], $_config['username'], 
                           $_config['password'], $_config['schema']);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
            $this->db_status=FALSE;
        }else{
            //echo "connection sucess";
            $this->db_status=TRUE;
        }
        return $conn;
    }
    
    function is_connected(){
        return $this->db_status;
    }
    
    function db_query($conn, $sql_query){
        global $_config;
        if ($this->db_status){
            $row = $conn->query($sql_query);
            return $row;
            /*if($row->num_rows > 0){
                while($record = $row->fetch_assoc()){
                    var_dump($record);
                }
            }else{
                echo "0 rows";
            }*/
        }
    } 
    
    function db_insertRecord($conn,$sql_query){
        if ($this->db_status){
            if($conn->query($sql_query) === TRUE){
                return TRUE;
            }else{
                return FALSE;
            }
        }
    }
    
    function db_close($conn){
        if ($this->db_status){
            $conn->close();
            $this->db_status=FALSE;
        }
    }
    

}

?>