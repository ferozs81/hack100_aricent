<?php

return array(
    'host' => 'localhost',
    'username' => 'root',
    'password' => 'bytecode',
    'schema' => 'hack100',
    'create_user_prifix' => 'INSERT INTO USERS (user_name,user_lname,
                                user_pass,user_mail) ',
    'create_ques_prifix' => 'INSERT INTO questions (question,bounty,
                                create_date, update_date, needed_date,
                                area_id, status_id,user_id) ',
    'select_user' => 'SELECT * FROM users where user_id = ',
    'get_problem_area' => 'SELECT * FROM problem_area',
    'get_problems' => 'SELECT * FROM questions',
    'update_problem' => 'UPDATE questions set status_id = ',
    'get_bounty' => 'SELECT * FROM bounty',
    'insert_bounty' => 'INSERT INTO bounty (question_id, user_id, solution) ',
    'problem_status' => 'SELECT * FROM problem_status',
    'select_user' => 'SELECT * from users where user_id = ',
    'problem_area' => 117,
    'question_state' => 1
);