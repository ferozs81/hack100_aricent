<?php

require ("hash.php");
include('server/db.php');

$db= new db();

$user_id = 42482;
$user_name = "munna";
$user_lname = "shaik";
$user_mail = "munna.shaik@aricent.com";
$password = "sai";
$pass_hash = PassHash::hash($password);
echo $pass_hash;
$conn=$db->db_connect();
$res=$db->db_query($conn, "INSERT into users (user_id,user_name,user_lname,user_pass,user_mail) values (".$user_id.",'".$user_name."','".$user_lname."','".$pass_hash."','".$user_mail."')");
echo "INSERT into users (user_id,user_name,user_lname,user_pass,user_mail) values (".$user_id.",'".$user_name."','".$user_lname."','".$pass_hash."','".$user_mail."')";
var_dump($res);
if($res){
    var_dump($res);
}
$db->db_close($conn);

?>